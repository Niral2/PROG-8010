﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BookCounter
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnResult_Click(object sender, RoutedEventArgs e)
        {
            int number;


            if (int.TryParse(txtNumberofbook.Text, out number))
            {

                switch (number)
                {
                    case 0:
                        MessageBox.Show("Congratulations " + txtName.Text + " you earned 0 point.!!", "Earned Point.");
                        break;
                    case 1:
                        MessageBox.Show("Congratulations " + txtName.Text + " you earned 5 points.!!", "Earned Point.");
                        break;
                    case 2:
                        MessageBox.Show("Congratulations " + txtName.Text + " you earned 15 points.!!", "Earned Point.");
                        break;
                    case 3:
                        MessageBox.Show("Congratulations " + txtName.Text + " you earned 30 points.!!", "Earned Point.");
                        break;
                    case 4:
                        MessageBox.Show("Congratulations " + txtName.Text + " you earned 60 points.!!", "Earned Point.");
                        break;
                    default:
                        MessageBox.Show("Congratulations " + txtName.Text + " you earned 60 points.!!", "Earned Point.");
                        break;

                }
            }





            else
            {
                MessageBox.Show("Please Enter Valid Number", "Earned Point");
            }
        }

        private void txtNumberofbook_GotFocus(object sender, RoutedEventArgs e)
        {
           // txtNumberofbook.Text = txtNumberofbook.Text ==" 0" ? string.Empty : txtNumberofbook.Text;
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            txtNumberofbook.Text = "0";
            txtName.Text = "";
        }
    }











}









